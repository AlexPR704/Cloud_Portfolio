import json
import boto3
import logging

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('VisitorCount')

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        response = table.update_item(
            Key={'id': 'resume'},
            UpdateExpression='SET #v = #v + :inc',
            ExpressionAttributeNames={'#v': 'views'},
            ExpressionAttributeValues={':inc': 1},
            ReturnValues='UPDATED_NEW'
        )

        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'views': int(response['Attributes']['views'])})
        }
    except Exception as e:
        logger.error(f"Error updating visitor count: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
